from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pandas as pd
import joblib


# --------------------------------------------------
# LOAD SAVED RANDOM FOREST MODEL
# --------------------------------------------------

model_package = joblib.load(
    "Forest_Fire_Random_Forest_Model.pkl"
)

model = model_package["model"]


# --------------------------------------------------
# CREATE FASTAPI APP
# --------------------------------------------------

app = FastAPI(
    title="Forest Fire Risk Prediction API",
    description="Backend API for forest fire prediction",
    version="1.0"
)


# --------------------------------------------------
# ENABLE CORS
# This allows the frontend to communicate
# with the Python backend.
# --------------------------------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


# --------------------------------------------------
# INPUT DATA FORMAT
# --------------------------------------------------

class FireInput(BaseModel):

    day: int
    month: int

    temperature: float
    relative_humidity: float
    wind_speed: float
    rain: float

    ffmc: float
    dmc: float
    dc: float
    isi: float
    bui: float
    fwi: float


# --------------------------------------------------
# TEST ROUTE
# --------------------------------------------------

@app.get("/")
def home():

    return {
        "status": "online",
        "message": "Forest Fire Prediction API is running"
    }


# --------------------------------------------------
# PREDICTION ROUTE
# --------------------------------------------------

@app.post("/predict")
def predict_fire(data: FireInput):

    # Convert user input into the same format
    # used during model training

    input_data = pd.DataFrame([{

        "Day": data.day,
        "Month": data.month,

        "Temperature": data.temperature,

        "Relative Humidity":
            data.relative_humidity,

        "Wind Speed":
            data.wind_speed,

        "Rain":
            data.rain,

        "Fine Fuel Moisture Code":
            data.ffmc,

        "Duff Moisture Code":
            data.dmc,

        "Drought Code":
            data.dc,

        "Initial Spread Index":
            data.isi,

        "Buildup Index":
            data.bui,

        "Fire Weather Index":
            data.fwi

    }])


    # Predict class
    prediction = int(
        model.predict(input_data)[0]
    )


    # Predict probability of FIRE
    probability = float(
        model.predict_proba(input_data)[0][1]
    )


    fire_probability = probability * 100

    safe_probability = 100 - fire_probability


    # Risk classification
    if fire_probability >= 80:

        risk_level = "Critical"

    elif fire_probability >= 60:

        risk_level = "High"

    elif fire_probability >= 35:

        risk_level = "Moderate"

    else:

        risk_level = "Low"


    # Return response to frontend

    return {

        "prediction": prediction,

        "label":
            "FIRE"
            if prediction == 1
            else "NOT FIRE",

        "fire_probability":
            round(fire_probability, 2),

        "safe_probability":
            round(safe_probability, 2),

        "risk_level":
            risk_level
    }