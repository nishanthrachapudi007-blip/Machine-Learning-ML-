// ------------------------------------
// FOREST PARTICLES
// ------------------------------------

const particleContainer =
    document.getElementById("particles");


for (let i = 0; i < 30; i++) {

    const particle =
        document.createElement("div");

    particle.classList.add("particle");

    particle.style.left =
        Math.random() * 100 + "vw";

    particle.style.animationDuration =
        8 + Math.random() * 15 + "s";

    particle.style.animationDelay =
        Math.random() * 10 + "s";

    particleContainer.appendChild(particle);

}


// ------------------------------------
// PREDICT FIRE
// ------------------------------------

async function predictFire() {

    const button =
        document.getElementById("predictButton");


    button.disabled = true;

    button.innerHTML =
        "<span>ANALYZING FOREST CONDITIONS...</span>";


    const data = {

        day:
            Number(document.getElementById("day").value),

        month:
            Number(document.getElementById("month").value),

        temperature:
            Number(document.getElementById("temperature").value),

        relative_humidity:
            Number(document.getElementById("humidity").value),

        wind_speed:
            Number(document.getElementById("windSpeed").value),

        rain:
            Number(document.getElementById("rain").value),

        ffmc:
            Number(document.getElementById("ffmc").value),

        dmc:
            Number(document.getElementById("dmc").value),

        dc:
            Number(document.getElementById("dc").value),

        isi:
            Number(document.getElementById("isi").value),

        bui:
            Number(document.getElementById("bui").value),

        fwi:
            Number(document.getElementById("fwi").value)

    };


    try {

        const response = await fetch(
            "http://127.0.0.1:8000/predict",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body:
                    JSON.stringify(data)
            }
        );


        if (!response.ok) {
            throw new Error(
                "Prediction API error"
            );
        }


        const result =
            await response.json();


        displayResult(result);

    }

    catch (error) {

        console.error(error);

        alert(
            "Could not connect to the ML server.\n\n" +
            "Make sure FastAPI is running."
        );

    }

    finally {

        button.disabled = false;

        button.innerHTML =
            `
            <span>RUN FIRE RISK ANALYSIS</span>
            <span>→</span>
            `;

    }

}



// ------------------------------------
// DISPLAY RESULT
// ------------------------------------

function displayResult(result) {

    document
        .getElementById("waitingState")
        .classList.add("hidden");


    document
        .getElementById("resultPanel")
        .classList.remove("hidden");


    const probability =
        result.fire_probability;


    const gauge =
        document.getElementById("riskGauge");


    const degrees =
        probability * 3.6;


    const fireDetected =
        result.prediction === 1;


    const color =
        fireDetected
            ? "#ff6845"
            : "#4ce393";


    gauge.style.background =
        `
        conic-gradient(
            ${color} ${degrees}deg,
            rgba(255,255,255,.07)
            ${degrees}deg
        )
        `;


    document
        .getElementById("probability")
        .innerText =
        probability.toFixed(1) + "%";


    const predictionText =
        document.getElementById(
            "predictionText"
        );


    if (fireDetected) {

        predictionText.innerHTML =
            "🔥 FIRE RISK DETECTED";

        predictionText.style.color =
            "#ff8061";

    }

    else {

        predictionText.innerHTML =
            "🌿 LOW FIRE RISK";

        predictionText.style.color =
            "#59e799";

    }


    document
        .getElementById("riskLevel")
        .innerText =
        result.risk_level;

}